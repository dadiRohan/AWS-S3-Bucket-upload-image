<?php
//https://medium.com/@ashan.fernando/upload-files-to-aws-s3-using-signed-urls-fa0a0cf489db
//https://docs.aws.amazon.com/AmazonS3/latest/API/sigv4-post-example.html
//https://blog.fineuploader.com/fine-uploader-s3-upload-directly-to-amazon-s3-from-your-browser-3d9dcdcc0f33


require 'vendor/autoload.php';

use Aws\S3\S3Client;
use Aws\S3\Exception\S3Exception;

if(isset($_FILES['UPLOAD']['name'])){

        $filename = $_FILES['UPLOAD']['name'];
        // print_r($filename);

    $IAM_KEY = 'AKIAJTY54ATZC6PB4RMQ'; 
    $IAM_SECRET = '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'; 
    // Set Amazon S3 Credentials
    $s3 = S3Client::factory(
        array(
            'credentials' => array(
                'key' => $IAM_KEY,
                'secret' => $IAM_SECRET
            ),
            'version' => 'latest',
            'region'  => 'ap-south-1'
        )
    );

    $bucketName = 'witbloxuploadtest';  
    $file_Path = 'uploadWit/'.$filename;
    $key = basename($file_Path);
    
    try {
        // Put on S3
        $result =  $s3->putObject([
            array(
                'Bucket'=>$bucketName,
                'Key' =>  $key,
                'Body' => fopen($file_Path,'r'),
                'ContentType' =>'image/jpeg',
                'ACL'  => 'public-read'    
            )
        ]);
        echo $result->get('ObjectURL');
    } catch (S3Exception $e) {
        echo $e->getMessage();
    } catch (Exception $e) {
        echo $e->getMessage();
    }

}

?>

<!DOCTYPE html>
<html>
<head>
    <title>File</title>
</head>
<body>
    <form action="" method="post" enctype="multipart/form-data">
        <input type="file" name="UPLOAD">
        <input type="submit" name="" value="submit">    
    </form>
</body>
</html>