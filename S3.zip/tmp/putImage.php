<?php
require 'vendor/autoload.php';
use Aws\S3\S3Client;
use Aws\S3\Exception\S3Exception;

// Set Amazon s3 credentials
$client = S3Client::factory(
  array(
    'key'    => "AKIAJGCGS2UAGJJZPCGA",
    'secret' => "tdx87S1ZUTIeP+GSun1im/4OSUmMK3o19w1lGlrU"
  )
);

try {
  $client->putObject(array(
    'Bucket'=>'witbloxuploadtest', //your-bucket-name
    'Key' =>  'https://s3.ap-south-1.amazonaws.com/witbloxuploadtest/uploadWit/', //your-filepath-in-bucket
    'SourceFile' => 'admin.jpg', //source-filename-with-path
    'StorageClass' => 'REDUCED_REDUNDANCY'
  ));

} catch (S3Exception $e) {
  // Catch an S3 specific exception.
  echo $e->getMessage();
}

?>