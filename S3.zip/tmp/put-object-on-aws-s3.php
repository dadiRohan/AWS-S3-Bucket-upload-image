<?php
	// $filePath = "https://s3.ap-south-1.amazonaws.com/witbloxuploadtest/uploadWit/coffee+3.jpg";

if(isset($_FILES['UPLOAD']['name'])){

	$filename = $_FILES['UPLOAD']['name'];
	// print_r($filename);
}

	require 'vendor/autoload.php';

	$bucketName = 'witbloxuploadtest';
	$filePath = __DIR__.$filename;
	$keyName = basename($filePath);

	$IAM_KEY = 'AKIAJTY54ATZC6PB4RMQ'; 
	$IAM_SECRET = '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'; 


	use Aws\S3\S3Client;
	use Aws\S3\Exception\S3Exception;

	// Set Amazon S3 Credentials
	$s3 = S3Client::factory(
		array(
			'credentials' => array(
				'key' => $IAM_KEY,
				'secret' => $IAM_SECRET
			),
			'version' => 'latest',
			'region'  => 'ap-south-1'
		)
	);
  

	try {
		// Create temp file
		$tempFilePath = 'tmp/tmpfile/' . basename($filePath);
		$tempFile = fopen($tempFilePath, "x+") or die("Error: Unable to open file.");
		$fileContents = file_get_contents($filePath);
		$tempFile = file_put_contents($tempFilePath, $fileContents);
		
		// Put on S3
		$s3->putObject(
			array(
				'Bucket'=>$bucketName,
				'Key' =>  $keyName,
				'SourceFile' => $tempFilePath,
				'StorageClass' => 'REDUCED_REDUNDANCY'
			)
		);
	} catch (S3Exception $e) {
		echo $e->getMessage();
	} catch (Exception $e) {
		echo $e->getMessage();
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>File</title>
</head>
<body>
	<form action="" method="post" enctype="multipart/form-data">
		<input type="file" name="UPLOAD">
		<input type="submit" name="" value="submit">	
	</form>
</body>
</html>